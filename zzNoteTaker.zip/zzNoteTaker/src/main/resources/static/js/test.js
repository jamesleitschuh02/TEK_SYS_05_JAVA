function demo() {
	alert("Thymeleaf with css and js demo");
}

//does not work for some reason
document.getElementById('#jBtn').addEventListener('click', console.log("another test"));